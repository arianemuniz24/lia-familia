import fs from 'node:fs';
import {makeSession} from '../public/voices.mjs';
const session=makeSession({language:'pt',voice:'rafael',turns:[],tasks:[],today:'2026-09-16',timezone:'America/Sao_Paulo',ingredients:''});
const env=Object.fromEntries(fs.readFileSync(new URL('../.env',import.meta.url),'utf8').split('\n').filter(l=>l.includes('=')&&!l.startsWith('#')).map(l=>{const i=l.indexOf('=');return [l.slice(0,i),l.slice(i+1).trim().replace(/^['"]|['"]$/g,'')]}));
import {proposalFromVoice} from '../public/core.mjs';
const base='https://lia-familia-figueira.netlify.app';
const config={};
const res=await fetch(base+'/api/voice-token',{method:'POST',headers:{Origin:base,'X-CSRF-Token':config.csrf||'','X-Demo-Code':env.LIA_ACCESS_CODE}});const auth=await res.json();if(!res.ok)throw Error(auth.error);
const ws=new WebSocket('wss://agents.assemblyai.com/v1/ws?token='+encodeURIComponent(auth.token));
const brief=[],turns=[],events=[],audio=[];let pending=[],sent=false,ended=false;
const wav=fs.readFileSync(new URL('../.build/task.wav',import.meta.url));let pos=12,pcm;while(pos+8<=wav.length){const len=wav.readUInt32LE(pos+4);if(wav.toString('ascii',pos,pos+4)==='data'){pcm=wav.subarray(pos+8,pos+8+len);break}pos+=8+len+(len%2)}if(!pcm)throw Error('No PCM');
const send=m=>{if(ws.readyState===1)ws.send(JSON.stringify(m))};
const timer=setTimeout(()=>send({type:'session.end'}),50000);
const hard=setTimeout(()=>{ws.close();finish()},55000);
function finish(){if(ended)return;ended=true;clearTimeout(timer);clearTimeout(hard);fs.writeFileSync(new URL('../docs/LIVE-QA.json',import.meta.url),JSON.stringify({time:new Date().toISOString(),input:'Synthetic Portuguese speech; no microphone capture',events,turns,brief,audioBytes:audio.reduce((n,b)=>n+b.length,0)},null,2)); fs.writeFileSync(new URL('../.build/voice-reply.pcm',import.meta.url),Buffer.concat(audio)); console.log('FINISHED',events.at(-1),turns.length,'turns',brief.length,'fields',audio.reduce((n,b)=>n+b.length,0),'audio bytes');}
ws.onopen=()=>send({type:'session.update',session});
ws.onmessage=async e=>{const m=JSON.parse(e.data);if(!['reply.audio','transcript.user.delta','transcript.agent.delta'].includes(m.type)){events.push({type:m.type,status:m.status,...(m.type.includes('error')?{message:m.message,code:m.code}:{})});console.log(m.type, m.type==='reply.done'?JSON.stringify(m):m.text||m.message||'')}
if(m.type==='session.ready'&&!sent){sent=true;await new Promise(r=>setTimeout(r,6000));for(let i=0;i<pcm.length&&ws.readyState===1;i+=4800){send({type:'input.audio',audio:pcm.subarray(i,i+4800).toString('base64')});await new Promise(r=>setTimeout(r,100))}for(let i=0;i<35&&ws.readyState===1;i++){send({type:'input.audio',audio:Buffer.alloc(4800).toString('base64')});await new Promise(r=>setTimeout(r,100))}}
if(m.type==='transcript.user')turns.push({id:'turn-'+turns.length,role:'user',text:m.text});
if(m.type==='transcript.agent')turns.push({id:'turn-'+turns.length,role:'agent',text:m.text});
if(m.type==='reply.audio')audio.push(Buffer.from(m.data,'base64'));
if(m.type==='tool.call')pending.push(m);
if(m.type==='reply.done'){if(m.status==='interrupted')pending=[];for(const call of pending.splice(0)){const result=proposalFromVoice(typeof call.arguments==='string'?JSON.parse(call.arguments):call.arguments,turns);if(result.ok)brief.push(result.draft);events.push({type:'tool.result',ok:result.ok,results:result.draft});send({type:'tool.result',call_id:call.call_id,result:JSON.stringify(result),is_error:!result.ok})}}
if(m.type==='session.ended'){finish();ws.close()}if(m.type.includes('error'))send({type:'session.end'});
};ws.onclose=finish;ws.onerror=()=>{console.log('WebSocket error');finish()};
