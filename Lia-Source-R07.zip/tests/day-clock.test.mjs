import test from 'node:test';import assert from 'node:assert/strict';
import {localDayKey,untilNextDay,startDayClock} from '../public/day-clock.mjs';
test('local calendar rolls over month and year without a hardcoded date',()=>{
 assert.equal(localDayKey(new Date(2026,11,31,23,59)), '2026-12-31');
 assert.equal(untilNextDay(new Date(2026,11,31,23,59,59)),1100);
 assert.equal(localDayKey(new Date(2027,0,1)), '2027-01-01');
});
test('open tab refreshes once at midnight and catches up after sleep',()=>{
 let date=new Date(2026,8,16,23,59,59),scheduled,wait,changes=[];
 const clock=startDayClock(d=>changes.push(d),{now:()=>date,setTimer:(fn,ms)=>{scheduled=fn;wait=ms;return 1},clearTimer:()=>{}});
 assert.equal(wait,1100);date=new Date(2026,8,17,0,0,1);scheduled();
 assert.deepEqual(changes,['2026-09-17']);clock.check();assert.equal(changes.length,1);
 date=new Date(2026,8,20,12);clock.check();assert.equal(changes.at(-1),'2026-09-20');
 assert.equal(wait,60000);clock.stop();date=new Date(2026,8,21);clock.check();assert.equal(changes.length,2);
});
