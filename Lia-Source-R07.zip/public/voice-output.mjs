export function clampVolume(value){const n=Number(value);return Number.isFinite(n)?Math.max(0,Math.min(1,n)):0.45}
let volume=0.45;const outputs=new Set();
export function setVoiceVolume(value){volume=clampVolume(value);for(const {ctx,node} of outputs){node.gain.cancelScheduledValues(ctx.currentTime);node.gain.setTargetAtTime(volume,ctx.currentTime,0.025)}return volume}
export function createVoiceOutput(ctx){const node=ctx.createGain();node.gain.value=volume;node.connect(ctx.destination);const entry={ctx,node};outputs.add(entry);return {node,dispose(){outputs.delete(entry);node.disconnect()}}}
