export function dateKey(d=new Date()){return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-')}
export function shiftDay(day,n){const [y,m,d]=day.split('-').map(Number),v=new Date(y,m-1,d+n,12);return dateKey(v)}
export function validDate(s){if(!/^\d{4}-\d{2}-\d{2}$/.test(s))return false;const [y,m,d]=s.split('-').map(Number);return y>=2020&&y<=2100&&dateKey(new Date(y,m-1,d,12))===s}
export function validateTask(a){return !!a&&typeof a.title==='string'&&a.title.trim().length>0&&a.title.length<=200&&validDate(a.date)&&(a.time===''||/^([01]\d|2[0-3]):[0-5]\d$/.test(a.time))}
export function proposal(args,turns){if(!args||typeof args.quote!=='string'||args.quote.length<3||!turns.some(t=>t.role==='user'&&t.text.includes(args.quote)))return {ok:false,error:'Use an exact quote from the user.'};if(typeof args.title!=='string'||!args.title.trim()||args.title.length>200)return {ok:false,error:'Task title required'};if(args.date&&!validDate(args.date))return {ok:false,error:'Use YYYY-MM-DD or empty for unknown date'};if(args.time&&!/^([01]\d|2[0-3]):[0-5]\d$/.test(args.time))return {ok:false,error:'Use HH:MM or empty for unspecified time'};return {ok:true,draft:{title:args.title.trim(),date:args.date||'',time:args.time||'',quote:args.quote}}}
export function agenda(tasks,day,view){return tasks.filter(t=>view==='done'?t.done:view==='all'?!t.done:!t.done&&(view==='today'?t.date<=day:t.date===shiftDay(day,1))).sort((a,b)=>(a.date+(a.time||'99:99')).localeCompare(b.date+(b.time||'99:99')))}
export function restore(raw){try{const a=JSON.parse(raw);if(!Array.isArray(a))return [];return a.filter(t=>validateTask(t)&&typeof t.id==='string').map(t=>({id:t.id,title:t.title,date:t.date,time:t.time,done:!!t.done,doneAt:validDate(t.doneAt||'')?t.doneAt:''})).slice(0,300)}catch{return []}}
const esc=s=>String(s).replace(/\\/g,'\\\\').replace(/\r?\n/g,'\\n').replace(/;/g,'\\;').replace(/,/g,'\\,');
export function calendar(tasks,stamp=new Date()){const lines=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//FIGUEIRA//Lia//EN','CALSCALE:GREGORIAN'];for(const t of tasks.filter(t=>!t.done&&validateTask(t))){lines.push('BEGIN:VEVENT','UID:'+esc(t.id)+'@lia.figueira','DTSTAMP:'+stamp.toISOString().replace(/[-:]/g,'').replace(/\.\d{3}/,''));if(t.time){lines.push('DTSTART:'+t.date.replace(/-/g,'')+'T'+t.time.replace(':','')+'00','DURATION:PT30M')}else lines.push('DTSTART;VALUE=DATE:'+t.date.replace(/-/g,''),'DTEND;VALUE=DATE:'+shiftDay(t.date,1).replace(/-/g,''));lines.push('SUMMARY:'+esc(t.title),'END:VEVENT')}lines.push('END:VCALENDAR');return lines.join('\r\n')+'\r\n'}

export function proposalFromVoice(args,turns,today=dateKey()){
 const result=proposal(args,turns);if(!result.ok)return result;
 // Resolve only explicit, unambiguous date/time forms. Everything else stays for review.
 const q=args.quote.toLowerCase();let date='',time='';
 const iso=q.match(/\b(20\d{2}-\d{2}-\d{2})\b/);if(iso&&validDate(iso[1]))date=iso[1];
 else if(/(?:amanhã|tomorrow|mañana|demain|domani|morgen)/u.test(q))date=shiftDay(today,1);
 else if(/\b(?:hoje|today|hoy|oggi|heute)\b|aujourd’hui|aujourd'hui/u.test(q))date=today;
 const hm=q.match(/\b([01]?\d|2[0-3]):([0-5]\d)\b/);
 const hour=q.match(/(?:às|as|at|a las|alle|um)\s+([01]?\d|2[0-3])\s*(?:horas|hora|h|o'clock|uhr)\b/u);
 if(hm)time=hm[1].padStart(2,'0')+':'+hm[2];else if(hour)time=hour[1].padStart(2,'0')+':00';
 return {...result,draft:{...result.draft,date,time}};
}
