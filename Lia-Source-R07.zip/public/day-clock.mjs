// Local calendar boundaries deliberately use calendar arithmetic, including DST days.
export function localDayKey(date=new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
}
export function untilNextDay(date=new Date()) {
  const next=new Date(date.getFullYear(),date.getMonth(),date.getDate()+1);
  return Math.max(250,next.getTime()-date.getTime()+100);
}
export function startDayClock(onChange,{now=()=>new Date(),setTimer=setTimeout,clearTimer=clearTimeout}={}) {
  let current=localDayKey(now()),timer,stopped=false;
  function check(){
    if(stopped)return;
    clearTimer(timer);
    const date=now(),next=localDayKey(date);
    if(next!==current){current=next;onChange(next)}
    // Also detect manual clock/timezone changes while the page remains visible.
    timer=setTimer(check,Math.min(untilNextDay(date),60000));
  }
  check();
  return {check,stop(){stopped=true;clearTimer(timer)}};
}
